# MADAPORC — Vues JSP + design system

39 fichiers JSP (incl. layout) + `app.css` + `app.js`, prêts à brancher sur vos contrôleurs Spring MVC.

## Arborescence

```
src/main/resources/static/css/app.css
src/main/resources/static/js/app.js
src/main/webapp/WEB-INF/views/
  layout/{header,sidebar,footer}.jsp   ← layout partagé (inclus par chaque page)
  login.jsp  placeholder.jsp
  dashboard/index.jsp
  utilisateurs/{liste,form}.jsp
  lots/{listeLots,formLot,detailLot,mouvements,pesees}.jsp
  reproduction/groupes/{liste,form,detail,confirmerMiseBas}.jsp
  reproduction/analyse/analyseLot.jsp
  reproduction/alertes/liste.jsp
  sante/{vaccins,formVaccin,vaccinations,formVaccination,suivis,formSuivi}.jsp
  commerce/{clients,formClient,ventes,formVente,detailVente}.jsp
  stocks/{ingredients,formIngredient,mouvements,formMouvement}.jsp
  finance/{depenses,formDepense}.jsp
  imports/{form,historique}.jsp
  rapports/index.jsp
```

## Convention de page

Chaque vue définit ses variables puis inclut le layout :

```jsp
<c:set var="pageTitle" value="Lots de porcs" />
<c:set var="crumbs"    value="Cheptel / <b>Lots</b>" />
<%@ include file="/WEB-INF/views/layout/header.jsp" %>
   ... contenu ...
<%@ include file="/WEB-INF/views/layout/footer.jsp" %>
```

`header.jsp` ouvre le shell, charge Inter + `app.css`, affiche la topbar et les messages flash, puis inclut `sidebar.jsp`. `footer.jsp` ferme le shell et charge `app.js`.

## Rappels d'intégration

1. **View resolver** (application.properties) :
   ```
   spring.mvc.view.prefix=/WEB-INF/views/
   spring.mvc.view.suffix=.jsp
   ```
2. **JSTL au classpath** — les vues utilisent les taglibs `c`, `fmt`, `fn`.
   - Spring Boot 2 / Tomcat javax : `jakarta` non requis ; gardez les URI `http://java.sun.com/jsp/jstl/*` (déjà en place) + dépendances `jstl` + `org.apache.tomcat.embed:tomcat-embed-jasper`.
   - **Spring Boot 3 (Jakarta)** : remplacez les URI par `jakarta.tags.core` / `jakarta.tags.fmt` / `jakarta.tags.functions` et utilisez `org.glassfish.web:jakarta.servlet.jsp.jstl`.
3. **Attributs de modèle attendus** (à fournir par les contrôleurs) : `dashboard`, `lots`, `filtre`, `lot`, `detail`, `groupes`, `groupe`, `analyse`, `alertes`, `utilisateurs`, `utilisateur`, `clients`, `client`, `ventes`, `vente`, `ingredients`, `ingredient`, `mouvements`, `vaccins`, `vaccin`, `vaccinations`, `vaccination`, `suivis`, `suivi`, `races`, `lotsFemelles`, `lotsMales`, `maladies`, `traitements`, `depenses`, `depense`, `categories`, `historique`, `nbAlertes`, et messages flash `success` / `error` / `warning` / `info`.
4. **Routes de formulaire** : chaque `<form>` poste vers la route documentée en commentaire JSP (ex. `/lots/save`, `/reproduction/groupes/{id}/confirmer-mise-bas`, `/stocks/mouvements/save`). Les routes de reproduction restent toutes sur `GroupeReproductionController`.

## Police & icônes
- **Police** : Nunito (Google Fonts), chargée dans `header.jsp` et `login.jsp`. La variable CSS `--font` la pilote pour toute l'app.
- **Icônes** : Font Awesome 6.5.2 (CDN cdnjs), classes `fa-solid fa-*`. Aucune dépendance locale ; pour un déploiement hors-ligne, téléchargez Font Awesome dans `static/` et remplacez le `<link>` CDN.

## JavaScript fourni (app.js)
Menu mobile, lien de nav actif (`data-match`), confirmations (`data-confirm`), filtre de tableau (`data-filter-input`), total automatique des ventes (`data-line`/`data-qty`/`data-price`/`data-total-out`), validation live de la mise bas (`data-nes`/`data-vivants`/`data-morts`).
